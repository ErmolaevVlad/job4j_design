# job4j_design

## О проекте

Этот проект предназначен для изучения курса Junior.

Темы курса:

1. Maven.
2. AssertJ.
3. Iterator.
4. Generic.
5. List.
6. Set.
7. Map.
8. Tree
9. Ввод-вывод
10. Socket
11. Логгирование
12. Сериализация
13. Настройка PostgreSQL
14. Create Update Insert
15. Query
16. Outer join
17. Объекты Базы данных
18. JDBC
19. Liquibase
20. Проект. Агрегатор Java вакансий
21. Понятие сборщик мусора
22. Виды сборщиков мусора
23. Профилирование приложения
24. Типы ссылок и коллекции на soft weak ссылках
25. Java Memory Model
26. TDD
27. SRP
28. OCP
29. LSP
30. ISP
31. DIP