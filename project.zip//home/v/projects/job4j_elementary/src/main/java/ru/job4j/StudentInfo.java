package ru.job4j;

public class StudentInfo {
    public static void main(String[] args) {
        System.out.println("Vlad Ermolaev");
        System.out.println("25.09.2022");
    }
}
